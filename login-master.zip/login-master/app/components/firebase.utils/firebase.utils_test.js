"use strict";
describe('fbutil', function() {
  beforeEach(function() {
    module('mock.firebase');
    module('firebase.utils');
  });

  describe('handler', function() {
    it('should have tests');
  });

  describe('defer', function() {
    it('should have tests');
  });

  describe('ref', function() {
    it('should have tests');
  });
});